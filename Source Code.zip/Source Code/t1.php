<?php
require_once '/Applications/AMPPS/www/vendor/autoload.php';
use Neoxygen\NeoClient\ClientBuilder;
if ($_POST["database"] == "m") {
    $m =new MongoClient();
    $c = $m ->project;

    $startYear=$_POST["start_year"];
    $endYear=$_POST["end_year"];
    $numOf=$_POST["min_votes"];
    $sort1=$_POST["sort"];
    $limit=$_POST["max_votes"];



    if($sort1=="DESC"){
        $sort=-1;
    }
    else
        $sort=1;

    $query='db.movieData.find(
        {$and:[
            {"startYear":{$gte:'.$startYear.'}},
            {"startYear":{$lte:'.$endYear.'}},
            {"ratings.numVotes":{$gt:'.$numOf.'}}
        ]
        },
        {_id:0,"primaryTitle":1,"startYear":1,"ratings":1}
    ).limit('.$limit.').sort({"ratings.averageRating":'.$sort.',"ratings.numVotes":-1}).toArray()'; 
    $first = $c->execute($query);
    $i=0;
    foreach($first as $row){
        if ($i>0)
            break;
        $result= json_encode($row);
        ++$i;    
    }
    echo $result;
}

else if ($_POST["database"] == "s") {
  # code...
      $servername = "localhost";
      $username = "root";
      $password = "mysql";
      $dbname = "IMDB";
      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      } 
      $start_year=$_POST["start_year"];
      $end_year=$_POST["end_year"];
      $min_votes=$_POST["min_votes"];
      $sort=$_POST["sort"];
      $max_votes=$_POST["max_votes"];
      $sql = "SELECT title_basics.primaryTitle as title, title_basics.startYear as year , title_ratings.averageRating as rating, title_ratings.numVotes as votes FROM title_basics, title_ratings WHERE title_basics.tconst = title_ratings.tconst AND title_basics.startYear >= ".$start_year." and title_basics.startYear <= ".$end_year." AND title_ratings.numVotes >= ".$min_votes."  ORDER BY title_ratings.averageRating ".$sort.", title_ratings.numVotes DESC LIMIT ".$max_votes;

      // echo $sql;
      $result = $conn->query($sql); 
      $data="";
      $array= array();
      class Genres{
        public $title;
        public $year;
        public $rating;
        public $votes;
      }
      while($row = $result->fetch_assoc()){
        $genres=new Genres();
        $genres->title = $row['title'];
        $genres->year = $row['year'];
        $genres->rating = $row['rating'];
        $genres->votes = $row['votes'];
        // $genres->sql = $sql;
        $array[]=$genres;
      }
      $data=json_encode($array);
      echo $data;
}

else{
    $startYear=$_POST["start_year"];
    $endYear=$_POST["end_year"];
    $numOf=$_POST["min_votes"];
    $sort=$_POST["sort"];
    $limit=$_POST["max_votes"];

    $client = ClientBuilder::create()
    ->addConnection('default', 'http','localhost',7474,true,'neo4j','1234')
    ->setAutoFormatResponse(true)
    ->build();
    if($sort=="DESC"){
            $query="Match (b:newbasic)<-[re:newevaluate_for]-(r:ratings) where b.startYear>=".$startYear." and b.startYear<=".$endYear." and r.numVotes>=".$numOf." return distinct b.primaryTitle as title, b.startYear as year, r.averageRating as rating, r.numVotes as votes order by r.averageRating DESC limit ".$limit;
        }else{
          $query="Match (b:newbasic)<-[re:newevaluate_for]-(r:ratings) where b.startYear>=".$startYear." and b.startYear<=".$endYear." and r.numVotes>=".$numOf." return distinct b.primaryTitle as title, b.startYear as year, r.averageRating as rating, r.numVotes as votes order by r.averageRating limit ".$limit;
        }
        $result = $client->sendCypherQuery($query);
        $output = $client->getResult()->getTableFormat();
        $json_string = json_encode($output);
        echo $json_string;
}  
?>