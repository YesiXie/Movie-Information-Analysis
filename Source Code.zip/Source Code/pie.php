<?php
    require_once '/Applications/AMPPS/www/vendor/autoload.php';
    use Neoxygen\NeoClient\ClientBuilder;

    $year=$_POST["year"];
    $database=$_POST["database"];

    if($database=="n"){
        $client = ClientBuilder::create()
		  ->addConnection('default', 'http','localhost',7474,true,'neo4j','1234')
		  ->setAutoFormatResponse(true)
		  ->build();
            $query="Match (b:newbasic) where b.startYear=".$year." return distinct b.genres as genre, count(*) as count order by count(*) DESC";
		    $result = $client->sendCypherQuery($query);
            $output = $client->getResult()->getTableFormat();
            $json_string = json_encode($output);
            echo $json_string;
    }else if($database=="m"){
          $m =new MongoClient();
    $c = $m ->project;
   $year=$_POST["year"];
   $query='db.movieData.aggregate(
       [
           {$unwind : "$genres"},
           {$match:{$and:[
               {"startYear":'.$year.'}
           ]}},
           {$group :
               {
                   _id : {"genres":"$genres"},
                   numOfMovie : {$sum : 1}
               }
           },
           {$sort:{"numOfMovie": 1}}
       ]
   ).toArray()';
   $first = $c->execute($query);
   $i=0;
   foreach($first as $row){
       if ($i>0)
           break;
       $result= json_encode($row);
       ++$i;   
   }
   echo $result;

    }else{
        $servername = "localhost";
        $username = "root";
        $password = "mysql";
        $dbname = "IMDB";
        $conn = new mysqli($servername, $username, $password, $dbname);
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } 

        $sql = "SELECT genre, COUNT(genres.titleId) as num
              FROM genres, title_basics
              WHERE title_basics.tconst = genres.titleId
                    AND title_basics.startYear = {$_POST['year']}
              GROUP BY genres.genre"; 

        $result = $conn->query($sql); 
        $data="";
        $array= array();
        class Genres{
          public $genre;
          public $count;
        }
        while($row = $result->fetch_assoc()){
          $genres=new Genres();
          $genres->genre = $row['genre'];
          $genres->count = $row['num'];
          $array[]=$genres;
        }
        $data=json_encode($array);
        echo $data;
    }
?>