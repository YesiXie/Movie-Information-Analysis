<?php
    require_once '/Applications/AMPPS/www/vendor/autoload.php';
    use Neoxygen\NeoClient\ClientBuilder;
    $database=$_POST["database"];
    // $database=m;
    if($database=="n"){
        $region=$_POST["region"];
        $genres=$_POST["genres"];
    
        $client = ClientBuilder::create()
            ->addConnection('default', 'http','localhost',7474,true,'neo4j','1234')
            ->setAutoFormatResponse(true)
            ->build();
            $query="Match (a:akas)<-[re:newdisplay_in]-(b:newbasic)<-[re1:newevaluate_for]-(r:ratings) where a.region='".$region."' and b.genres='".$genres."' return DISTINCT b.startYear as year, sum(r.numVotes) as rating order by b.startYear";
            $result = $client->sendCypherQuery($query);
            $output = $client->getResult()->getTableFormat();
            $json_string = json_encode($output);
            echo $json_string;
    }
    else if($database=="m"){
    $m =new MongoClient();
    $c = $m ->project;
    $region=$_POST["region"];
    $genres=$_POST["genres"];
    // $region=US;
    // $genres=Drama;
    $query='db.movieData.aggregate(
        [
            {$unwind : "$genres"},
            {$unwind : "$akas"},
            {$match:{$and:[
                {"genres":"'.$genres.'"},
                {"akas.region":"'.$region.'"}
            ]}},
            {$group :
                {
                    _id : {"year":"$startYear"},
                    numVotes : {$sum : "$ratings.numVotes"}
                }
            },
            {$sort:{"_id.year": 1}}
        ]
    ).toArray()'; 
    $first = $c->execute($query);
    $i=0;
    foreach($first as $row){
        if ($i>0)
            break;
        $result= json_encode($row);
        ++$i;    
    }
    echo $result;
}else{
    $servername = "localhost";
      $username = "root";
      $password = "mysql";
      $dbname = "IMDB";
      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      } 

      // $sql = "SELECT title_basics.startYear as genre, SUM(title_ratings.numVotes) as averageRating
      //         FROM genres, title_ratings, title_basics, title_akas 
      //         WHERE title_ratings.tconst = genres.titleId 
      //               AND title_ratings.tconst = title_basics.tconst 
      //               AND title_ratings.tconst = title_akas.titleId 
      //               AND genres.genre = '{$_POST['genres']}' 
      //               AND title_akas.region = '{$_POST['region']}' 
      //         GROUP BY title_basics.startYear 
      //         ORDER BY SUM(title_ratings.numVotes) DESC
      //         LIMIT 10"; 
      $sql = "SELECT year as genre, SUM(numOfVote) as averageRating
                from line
                where region = '{$_POST["region"]}' and genre = '{$_POST["genres"]}'
                GROUP BY year";
      $result = $conn->query($sql); 
      $data="";
      $array= array();
      class Genres{
        public $genre;
        public $count;
      }
      while($row = $result->fetch_assoc()){
        $genres=new Genres();
        $genres->genre = $row['genre'];
        $genres->count = $row['averageRating'];
        $array[]=$genres;
      }
      $data=json_encode($array);
      echo $data;
}
?>