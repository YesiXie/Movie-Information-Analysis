<center>
<!DOCTYPE html>
<html lang="en">
 <head>
  <meta charset="utf-8"> 
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <title>Homepage</title>
 </head>

<body>
<img src="pic/0.jpg" />
<div style=" height:75px; width:1500px; margin:0 auto; overflow: auto; _display:inline-block; background-color: #000000;" >
	<table border="0" cellpadding="0" cellspacing="0" width=900px height=75px>
  		<tr>
			<td width="80" align="center" bgcolor=orangered><a href="index.html" style="text-decoration:none"><font size="4" color="white" face="Candara"><div>HOME</div></font></a></td>
    		<td width="80" align="center"><a href="rating.html" style="text-decoration:none"><font size="4" color="white" face="Candara"><div>Rating</div></font></a></td>
			<td width="80" align="center"><a href="stat.html" style="text-decoration:none"><font size="4" color="white" face="Candara"><div>Statistics</div></font></a></td>
			<td width="80" align="center"><a href="stat.html" style="text-decoration:none"><font size="4" color="white" face="Candara"><div>Contact us</div></font></a></td>
  		</tr>
	</table>
</div>
<div style="position:relative;width:1500px; float:center; background-color: #000000;">
	<img src="pic/index.jpg" />
</div>
<br>  
</br>  
<div style="width:1200; margin:0 auto; overflow: auto; _display:inline-block;">
	<div style="width:400px; float:left">
		<table width = "380" style="border-collapse:separate; border-spacing:0px 12px; font-size:18px;">
		<tr><td align="center"><img src="pic/a3.jpg"/></td></tr>
		<tr><td><center><font color="black" face="Candara">The most popular movie <b>Avengers</b></font></center></td></tr>
		</table>
	</div>
	<div style="width:400px; float:left">
		<table width = "380" style="border-collapse:separate; border-spacing:0px 12px; font-size:18px;">			
		<tr><td align="center"><img src="pic/a1.jpg"/></td></tr>
<tr><td height="27"><center><font face="Candara">The most popular actress <b>Anne Hathaway</b></font></center></td></tr>
		</table>
	</div>	
	<div style="width:400px; float:right">
		<table width = "380" style="border-collapse:separate; border-spacing:0px 12px; font-size:18px;">			
		<tr><td align="center"><img src="pic/a2.jpg"/></td></tr>
<tr><td align="center"><font face="Candara">The most popular actor <b>Miles Teller</b></font></td></tr>
		</table>
	</div>
</div>
</br>
<table width="1500" height="100" style="border-collapse:separate; border-spacing:15px 8px; font-size:13px; font-family:Arial; color:black;"  bgcolor="#a49e93">
	<tr><td align="center">&copy; University of Pittsburgh. All rights reserved.</td></tr>
	<tr><td height="60"></td></tr>
</table>
</body>
</html>
</center>