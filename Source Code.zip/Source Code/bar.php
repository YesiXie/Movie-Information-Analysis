<?php
   require_once '/Applications/AMPPS/www/vendor/autoload.php';
   use Neoxygen\NeoClient\ClientBuilder;
   $database =$_POST["database"];
   if($database=="m"){
       $m =new MongoClient();
       $c = $m ->project;
       $year=$_POST["year"];
       $genres=$_POST["genres"];
       $query='db.movieData.aggregate(
           [
               {$unwind : "$genres"},
               {$unwind : "$akas"},
               {$match:{$and:[
                   {"genres":"'.$genres.'"},
                   {"startYear":'.$year.'}
               ]}},
               {$group :
                   {
                       _id : {"region":"$akas.region"},
                       numVotes : {$sum : 1}
                   }
               },
               {$sort:{"_id.region": 1}}
           ]
       ).toArray()';
       $first = $c->execute($query);
       $i=0;
       foreach($first as $row){
           if ($i>0)
               break;
           $result= json_encode($row);
           ++$i;   
       }
       echo $result;
   }
   else if ($database=="n"){

    $year=$_POST["year"];
    $genres=$_POST["genres"];

    $client = ClientBuilder::create()
    ->addConnection('default', 'http','localhost',7474,true,'neo4j','1234')
    ->setAutoFormatResponse(true)
    ->build(); 
        $query="Match (a:akas)<-[r:newdisplay_in]-(b:newbasic) where b.startYear=".$year." and b.genres='".$genres."' return a.region as region, count(*) as num order by num DESC";
        $result = $client->sendCypherQuery($query);
        $output = $client->getResult()->getTableFormat();
        $json_string = json_encode($output);
        echo $json_string;

   }
   else{
      $servername = "localhost";
      $username = "root";
      $password = "mysql";
      $dbname = "IMDB";
      $conn = new mysqli($servername, $username, $password, $dbname);
      if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
      } 

      $sql = "SELECT region as genre, SUM(numOfMovie) as averageRating FROM bar WHERE year = {$_POST['year']} and genre = '{$_POST['genres']}' GROUP BY region order by averageRating"; 
      $result = $conn->query($sql); 

      $data="";
      $array= array();
      class Genres{
        public $genre;
        public $count;
      }
      while($row = $result->fetch_assoc()){
        $genres=new Genres();
        $genres->genre = $row['genre'];
        $genres->count = $row['averageRating'];
        $array[]=$genres;
      }
      $data=json_encode($array);
      echo $data;
   }
?>
